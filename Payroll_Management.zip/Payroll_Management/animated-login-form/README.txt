A Pen created at CodePen.io. You can find this one at https://codepen.io/boudra/pen/YXzLBN.

 A simple animated login form