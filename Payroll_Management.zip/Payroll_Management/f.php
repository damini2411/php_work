<?PHP
include("adminpanel.php");

$admin = new Admin;

//$employee->tempConnection();

$name = $rdo1Chcked=$rdo2Chcked=$gender="";
$dob = $address = $city = $province = $postalCode="";
$empEmail = $empWebsite = $Joiningdate = $annualPay ="";
$errName = $errGender = $errDOB = $errAddress = $errCity = $errProvince = $errPostalCode = $errEmail= $errURL= $errJoiningDate="";
$errAnnualPay = "";
$valid = true;

if($_SERVER["REQUEST_METHOD"] == "POST"){

//	VALUES ('$this->name', '$this->gender','$this->email','$this->url','$this->dob','$this->address','$this->city','$this->province','$this->zipcode','$this->joinDate','$this->basicPay')";

	if(isset($_POST["empName"])){
		$name = $_POST["empName"];
		$admin->setName($name);
	}
	if(empty($_POST["empName"])){
		$errName="Please enter name";
		$valid = false;
	}

	if(isset($_POST["gender"])){
		$gender = $_POST["gender"];
		$admin->setGender($gender);
		if($_POST["gender"]=="Male"){
			$rdo1Chcked = "Checked";
		}elseif($_POST["gender"]=="Female"){
			$rdo2Chcked = "Checked";
		}
	}else{
		$errGender = "Please select any option";
		$valid = false;
	}

	if(isset($_POST["empEmail"])){
		$empEmail = $_POST["empEmail"];
		$admin->setEmail($empEmail);
	}
	if(empty($_POST["empEmail"])){
		$errEmail="Please enter Email";
		$valid = false;
	}

	if(isset($_POST["empWebsite"])){
		$empWebsite = $_POST["empWebsite"];
		$admin->setUrl($empWebsite);
	}
	if(empty($_POST["empWebsite"])){
		$errURL="Please enter Url";
		$valid = false;
	}

	if(isset($_POST["dob"])){
		$dob = $_POST["dob"];
		$admin->setDob($dob);
	}
	if(empty($_POST["dob"])){
		$errDOB="Please enter Date Of Birth";
		$valid = false;
	}

	if(isset($_POST["address"])){
		$address = $_POST["address"];
		$admin->setAddress($address);
	}
	if(empty($_POST["address"])){
		$errAddress="Please enter Street Address";
		$valid = false;
	}

	if(isset($_POST["city"])){
		$city = $_POST["city"];
		$admin->setCity($city);
	}
	if(empty($_POST["city"])){
		$errCity="Please enter City";
		$valid = false;
	}

	if(isset($_POST["province"])){
		$province = $_POST["province"];
		$admin->setProvince($province);
	}
	if(empty($_POST["province"])){
		$errProvince="Please enter Province";
		$valid = false;
	}

	if(isset($_POST["postalCode"])){
		$postalCode = $_POST["postalCode"];
		$admin->setZipcode($postalCode);
	}
	if(empty($_POST["postalCode"])){
		$errPostalCode="Please enter Postl Code";
		$valid = false;
	}

	if(isset($_POST["Joiningdate"])){
		$Joiningdate = $_POST["Joiningdate"];
		$admin->setJoiningDate($Joiningdate);
	}
	if(empty($_POST["Joiningdate"])){
		$errJoiningDate="Please enter Joining Date";
		$valid = false;
	}

	if(isset($_POST["annualPay"])){
		$annualPay = $_POST["annualPay"];
		$admin->setBasicpay($annualPay);
	}
	if(empty($_POST["annualPay"])){
		$errAnnualPay="Please enter Annual Pay";
		$valid = false;
	}
	if($valid){
		$admin->insert();
		header('Location: index.php');
		exit();
	}
	
	
	
}
?>

<!DOCTYPE HTML>
<html>
<head>
<title>Modern an Admin Panel Category Flat Bootstarp Resposive Website Template | Forms :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div id="wrapper">
     <!-- Navigation -->
        <nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">PMS</a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
				
			    <li class="dropdown">
	        		
						
					<li class="m_2"><a href="#"><i class="fa fa-lock"></i> Logout</a></li>	
	        		</ul>
	      		</li>
			</ul>
			<form class="navbar-form navbar-right">
              <input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
            </form>
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="index.html"><i class="fa fa-dashboard fa-fw nav_icon"></i>Login</a>
                        </li>
                        
                         <li>
                            <a href="f.php"><i class="fa fa-check-square-o nav_icon"></i>Add Employees<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    </a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="basic_tables.php"><i class="fa fa-table nav_icon"></i>View Employees<span class="fa arrow"></span></a>
                            
                            <!-- /.nav-second-level -->
                        </li>
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <div id="page-wrapper">
        <div class="graphs">
	     <div class="xs">
  	       <h3>Add Employee</h3>
  	         <div class="tab-content">
						<div class="tab-pane active" id="horizontal-form">
							<form class="form-horizontal">
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Employee Name</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="empName" id="empName" placeholder="Employee Name" value="<?php echo htmlspecialchars($name)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errName);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="radio" class="col-sm-2 control-label">Gender</label>
									<div class="col-sm-8">
										<div class="radio block"><label><input type="radio" name="gender" value="Male" <?php echo htmlspecialchars ($rdo1Chcked);?>> Male</label></div>
										<div class="radio block"><label><input type="radio" name="gender" value="Female" <?php echo htmlspecialchars ($rdo2Chcked);?>> FeMale</label></div>
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errGender);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Date of Birth</label>
									<div class="col-sm-8">
										<input type="datetime" class="form-control1" name="dateOfBirth" id="dateOfBirth" placeholder="YYYY-MM-DD" value="<?php echo htmlspecialchars($dateOfBirth)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errDOB);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Street Address</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="address" id="address" placeholder="Street Address" value="<?php echo htmlspecialchars($address)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errAddress);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">City</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="city" id="city" placeholder="City" value="<?php echo htmlspecialchars($city)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errCity);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Province</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="province" id="province" placeholder="Province" value="<?php echo htmlspecialchars($province)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errProvince);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Postal Code</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="postalCode" id="postalCode" placeholder="Postal Code" value="<?php echo htmlspecialchars($postalCode)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errPostalCode);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Email Address</label>
									<div class="col-sm-8">
										<input type="email" class="form-control1" name="empEmail" id="empEmail" placeholder="abc@gmail.com" value="<?php echo htmlspecialchars($empEmail)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errEmail);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">LinkedIn URL</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="empLinkedIn" id="empLinkedIn" placeholder="Employee LinkedIn Profile URL" value="<?php echo htmlspecialchars($empLinkedIn)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errURL);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Joining Date</label>
									<div class="col-sm-8">
										<input type="datetime" class="form-control1" name="dateOfJoining" id="dateOfJoining" placeholder="YYYY-MM-DD" value="<?php echo htmlspecialchars($dateOfJoining)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errJoiningDate);?></p>
									</div>
								</div>
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Annual Basic Pay</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" name="annualPay" id="annualPay" placeholder="AnnualPay" value="<?php echo htmlspecialchars($annualPay)?>">
									</div>
									<div class="col-sm-2 jlkdfj1">
										<p class="help-block"><?php echo ($errAnnualPay);?></p>
									</div>
								</div>
					
					<div class="bs-example" data-example-id="form-validation-states">
    
      <div class="panel-footer">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
				<button class="btn-success btn">Submit</button>
				<button class="btn-default btn">Cancel</button>
				<button class="btn-inverse btn">Reset</button>
			</div>
		</div>
	 </div>
    </form>
  </div>
  </div>
  <div class="copy_layout">
      <p>Copyright © 2017 . All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">Payroll Management</a> </p>
  </div>
  </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>
