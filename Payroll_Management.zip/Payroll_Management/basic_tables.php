<?php
include("adminpanel.php");

// $admin = new Admin;

//Comment this code After connection has been established, Database Created and Record Inserted
// $admin->createconn();
// $admin->createDB();
// $admin->createTB();
// $admin->insert();
//Comment this code After connection has been established, Database Created and Record Inserted

//$admin->tempConnection();



$sql = "SELECT empId as id, empName as name, CONCAT(address , ' ' , city , ' ' , province , ' ' , postalcode) as address, email as emailid FROM Employee_master order by name;";
// $result = mysqli_query($admin->conn, $sql);
$result = $conn->query($sql);
//echo $result;
if (mysql_num_rows($result) > 0) {
$totalRecords=mysql_num_rows($result);
}


?>
 
<!DOCTYPE HTML>
<html>
<head>
<title>Payroll Management System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Modern Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<script src="js/jquery.min.js"></script>
<!----webfonts--->
<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
<!---//webfonts--->  
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<div id="wrapper">
     <!-- Navigation -->
        <nav class="top1 navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
           <!-- <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">Modern</a>
            </div>
            <! /.navbar-header -->
            <ul class="nav navbar-nav navbar-right">
				<li class="dropdown">
	        		<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-comments-o"></i></a>
	        		<ul class="dropdown-menu">
						<li class="dropdown-menu-header">
							
						<li class="m_2"><a href="#"><i class="fa fa-user"></i> Profile</a></li>
						<li class="m_2"><a href="#"><i class="fa fa-wrench"></i> Settings</a></li>
						
						<li class="m_2"><a href="#"><i class="fa fa-lock"></i> Logout</a></li>	
	        		</ul>
	      		</li>
			</ul>
			<form class="navbar-form navbar-right">
              <input type="text" class="form-control" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
            </form>
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="index.html"><i class="fa fa-dashboard fa-fw nav_icon"></i>Login</a>
                        </li>
                        
                         <li>
                            <a href="forms.php"><i class="fa fa-check-square-o nav_icon"></i>Add Employees<span class="fa arrow"></span></a>
                            
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="basic_tables.php"><i class="fa fa-table nav_icon"></i>View Employees<span class="fa arrow"></span></a>
                            
                            <!-- /.nav-second-level -->
                        </li>
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <div id="page-wrapper">
        <div class="col-md-12 graphs">
	   <div class="xs">
  	
	<div class="panel panel-warning" data-widget="{&quot;draggable&quot;: &quot;false&quot;}" data-widget-static="">
				<div class="panel-heading">
					<h2>Employee List</h2>
					<div class="panel-ctrls" data-actions-container="" data-action-collapse="{&quot;target&quot;: &quot;.panel-body&quot;}"><span class="button-icon has-bg"><i class="ti ti-angle-down"></i></span></div>
				</div>
				
          <h3 class="blank1"></h3>

           <div class="xs tabls">
            <div class="bs-example4" data-example-id="contextual-table">
            <table class="table">
              <thead>
              <tr>
                <th style="display: none;">ID</th>
                <th>Name</th>
                <th>Address</th>
                <th colspan="3">Email ID</th>
              </tr>
              </thead>
              <tbody>
               <?php
               if(mysqli_num_rows($result) > 0) {
                 while($row=mysqli_fetch_assoc($result)){

                  ?>
                <tr class="success">
                <td style="display: none;"><?php echo $row['id']; ?></td> 
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['address']; ?></td>  
                <td><?php echo $row['emailid']; ?></td>
                <!-- <td><img src="edit-icon.jpg" height="35px" width="35px" onclick="update.php"></td>  -->
                 <td>
                                            <!-- echo "<a href='read.php?id=". $row['id'] ."' title='View Record' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>"; -->
                                            <a href="update.php?id=<?php echo$row['id'];?>" ><span class='glyphicon glyphicon-pencil'></span></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <a href='delete.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>
                                        </td>
              </tr>
              <?php        
                 }
               }
               ?>

              </tbody>
            </table>
             </div>

  
        
        
      </div>
    </div>
	<div class="bs-example4" data-example-id="simple-responsive-table">
    <div class="table-responsive">
     
  <div class="copy_layout">
      <p>Copyright © 2017 . All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">Payroll Management</a> </p>
  </div>
  </div>
   </div>
      </div>
      <!-- /#page-wrapper -->
   </div>
    <!-- /#wrapper -->
<!-- Nav CSS -->
<link href="css/custom.css" rel="stylesheet">
<!-- Metis Menu Plugin JavaScript -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>
