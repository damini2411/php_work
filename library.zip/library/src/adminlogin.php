<?php
include 'dbinfo.php'; 
?>  
<?php

//always start the session before anything else!!!!!! 
session_start(); 
//connect to the db 
$username = $_SESSION['username'];
unset($_SESSION['isbn']);
unset($_SESSION['copyid']);	


$sql = "SELECT ISBN as isbn, Title as title, Publisher as publisher, IsReserved as available FROM book order by title;";
$result = mysqli_query($conn, $sql);
$result = $conn->query($sql);
//echo $result;
// if (mysql_num_rows($result) > 0) {
// $totalRecords=mysql_num_rows($result);
// }
?> 
<html>
<head>
<title>Admin Department</title>
<style>

body{
	background-color: azure;
	margin-top: 50px;
}
h1{
	color: navy;
}
.btn{
	border-radius: 20px;
	background-color: white;
	color: coral;
	float: left;
}
.label{
	color: cornflowerblue;
}
.table
{
	border:2px solid black;
	margin: 5px;
	padding: 5px;
}

</style>
</head>
<body>
<center>
<h1>Admin Summary</h1>

<form action="PopularSubjectReport.php" method="post">
<input class="btn" type="submit" value="Popular Subject Report"/>
</form>

<form action="FrequentUsersReport.php" method="post">
<input class="btn" type="submit" value="Frequent User Report"/>
</form>

<form action="PopularBooksReport.php" method="post">
<input class="btn" type="submit" value="Popular Books Report"/>
</form>

<form action="DamagedBooksReport.php" method="post">
<input class="btn" type="submit" value="Damaged Books Report"/>
</form>

<form action="LostDamagedBook_Admin.php" method="post">
<input class="btn" type="submit" value="Lost/Damaged Book"/>
</form>

<form action="Login.php" method="post">
<input class="btn" type="submit" value="Close"/><br><br>

<table class="table">
              <thead>
              <tr>
                <th style="border-right: 2px solid black;">ISBN</th>
                <th style="border-right: 2px solid black;">Title</th>
                <th style="border-right: 2px solid black;">Publisher</th>
                <th>Available copies</th>
              </tr>
              </thead>
              <tbody>
              <?php
               if(mysqli_num_rows($result) > 0) {
                 while($row=mysqli_fetch_assoc($result)){

                  ?>
                <tr class="success">
                <td style="border-right: 2px solid black;"><?php echo $row['isbn']; ?></td> 
                <td style="border-right: 2px solid black;"><?php echo $row['title']; ?></td>
                <td style="border-right: 2px solid black;"><?php echo $row['publisher']; ?></td>  
                <td><?php echo $row['available']; ?></td>
                <!-- <td><img src="edit-icon.jpg" height="35px" width="35px" onclick="update.php"></td>  -->
                 <td>
                                            <!-- echo "<a href='read.php?id=". $row['id'] ."' title='View Record' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>"; -->
                                            <a href="update.php?id=<?php echo$row['id'];?>" ><span class='glyphicon glyphicon-pencil'></span></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <a href='delete.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>
                                        </td>
              </tr>
              <?php        
                 }
               }
               ?>

              </tbody>
</form>

</center>
</body>
</html>
