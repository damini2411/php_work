<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "";

	//Create connection

	$conn = new mysqli($servername,$username,$password);

	// Check connection

	if ($conn->connect_error)
	{
		die("connection failed:" . $conn->connect_error);
	}
	else
	{
		//echo "connection successful<br>";
	}

	$sql = "CREATE DATABASE if not exists C0705705_Library";
	if ($conn->query($sql)===FALSE)
	{
		echo "Error creating database:" . $conn->error;
	}
	else
	{
		//echo "Datebase created successfully. <br>";
	}

	$sql = "Use C0705705_Library";
	if ($conn->query($sql)=== TRUE)
	{

	$sql = "CREATE TABLE if not exists author("
."ISBN int(14) NOT NULL AUTO_INCREMENT primary kEY,"
."Author varchar(60) NOT NULL)";

if ($conn->query($sql)===TRUE)
		{
			//echo "Table created successfully. <br>";
		}
		else
		{
			echo "Error creating Table :" . $conn->error;
		}

}
	else
	{
		echo "Error connecting database:" . $conn->error. "<br>";
	}


// Insert into author

"INSERT INTO author (ISBN, Author) VALUES
('0123704901', 'Chetan Bhagat'),
('0123704901', 'Kajal oza'),
('0123944244', 'Vijaliwala'),
('0123944244', 'Sarah Harris'),
('0124077269', 'David A. Patterson'),
('0124077269', 'John L. Hennessy'),
('0205973361', 'J. Noland White'),
('0205973361', 'Saundra K. Ciccarelli'),
('0321696867', 'Hugh D. Young'),
('0321696867', 'Roger A. Freedman'),
('0321740904', 'Randall D. Knight'),
('0321884078', 'George B. Thomas Jr'),
('0321884078', 'Joel R. Hass'),
('0321884078', 'Maurice D. Weir'),
('0470879521', 'John D. Cutnell'),
('0470879521', 'Kenneth W. Johnson'),
('0596802358', 'Philipp K. Janert'),
('099040207X', 'Mr. Martin Holzke'),
('099040207X', 'Mr. Tom Stachowitz'),
('1285057090', 'Bruce H. Edwards'),
('1285057090', 'Ron Larson'),
('1429237198', 'Daniel L. Schacter'),
('1429237198', 'Daniel T. Gilbert'),
('1429261781', 'David G. Myers'),
('1449600069', 'Julia Lobur'),
('1449600069', 'Linda Null'),
('1452257876', 'A. Michael Huberman'),
('1452257876', 'Matthew B. Miles'),
('1590597699', 'Clare Churcher');";

if ($conn->multi_query($sql)===TRUE)
		{
			$last_id = $conn->insert_id;
			//echo "New record inserted successfully. <br>";
		}
		else
		{
			echo "Error creating record :" . $conn->error;
		}
	
// table book
	
$sql = "Use C0705705_Library";
	if ($conn->query($sql)=== TRUE)
	{

	$sql = "CREATE TABLE if not exists book("
."ISBN int(14) NOT NULL AUTO_INCREMENT primary kEY,"
."Title varchar(100) NOT NULL,"
."IsReserved tinyint(1) NOT NULL,"
."Edition int(11) NOT NULL,"
."Publisher varchar(30) NOT NULL,"
."CopyYr decimal(4,0) NOT NULL,"
."ShelfID int(11) DEFAULT NULL,"
."SubName varchar(30) DEFAULT NULL)";
  
  
  	if ($conn->query($sql)===TRUE)
		{
			//echo "Table created successfully. <br>";
		}
		else
		{
			echo "Error creating Table :" . $conn->error;
		}

}
	else
	{
		echo "Error connecting database:" . $conn->error. "<br>";
	}


// Insert into author

"INSERT INTO book (ISBN, Title, IsReserved, Edition, Publisher, CopyYr, ShelfID, SubName) VALUES
('0123704901', 'Computer Architecture: A Quantitative Approach',0, 4,'Morgan Kaufmann', '2006', 321, 'Computer Architecture'),
('0123944244', 'Digital Design and Computer Architecture', 0, 2, 'Morgan Kaufmann', '2012', 311, 'Computer Architecture'),
('0124077269', 'Computer Organization and Design',0, 5,'Morgan Kaufmann', '2013', 312,'Computer Architecture'),
('0205973361', 'Psychology',0, 4, 'Pearson', '2014', 232, 'Psychology'),
('0321696867', 'University Physics with Modern Physics',0, 13, 'Addison-Wesley', '2011', 211, 'Physics'),
('0321740904', 'Physics for Scientists and Engineers: A Strategic Approach with Modern Physics',1, 3, 'Addison-Wesley', '2012', 212, 'Physics'),
('0321884078', 'Thomas'' Calculus: Early Transcendentals',0, 13,'Pearson', '2013', 111, 'Calculus'),
('0470879521', 'Physics',0, 9,'John Wiley and Sons', '2012', 212, 'Physics'),
('0596802358', 'Data Analysis with Open Source Tools',0, 1,'O''Reilly Media', '2010', 131, 'Data Science'),
('099040207X', 'SQL Database for Beginners',0, 1,'LearnToProgram, Incorporated ', '2014', 121, 'Data Science'),
('1285057090', 'Calculus', 1, 10, 'Cengage Learning', '2013', 112, 'Calculus'),
('1429237198', 'Psychology ', 1, 2,  'Worth Publishers', '2010', 231, 'Psychology'),
('1429261781', 'Psychology',0, 10,  'Worth Publishers', '2011', 222, 'Psychology'),
('1449600069', 'The Essentials of Computer Organization and Architecture', '215.95', 0, 3, '', 'Jones & Bartlett Learning', '2010', 322, 'Computer Architecture'),
('1452257876', 'Qualitative Data Analysis: A Methods Sourcebook',  0, 3, 'SAGE Publications, Inc', '2013', 132, 'Data Science'),
('1590597699', 'Beginning Database Design: From Novice to Professional ',  0, 1,  'Apress', '2007', 122, 'Data Science');";

if ($conn->multi_query($sql)===TRUE)
		{
			$last_id = $conn->insert_id;
			//echo "New record inserted successfully. <br>";
		}
		else
		{
			echo "Error creating record :" . $conn->error;
		}


// Table

		$sql = "Use C0705705_Library";
	if ($conn->query($sql)=== TRUE)
	{

	$sql = "CREATE TABLE if not exists bookcopy("
."ISBN int(14) NOT NULL,"
."CopyID int(11) NOT NULL AUTO_INCREMENT primary kEY,"
."IsChecked tinyint(1) NOT NULL,"
."IsHold tinyint(1) NOT NULL,"
."IsDamaged tinyint(1) NOT NULL)";


  if ($conn->query($sql)===TRUE)
		{
			//echo "Table created successfully. <br>";
		}
		else
		{
			echo "Error creating Table :" . $conn->error;
		}

}
	else
	{
		echo "Error connecting database:" . $conn->error. "<br>";
	}


	// Table insert

	"INSERT INTO bookcopy (ISBN, CopyID, IsChecked,IsHold,IsDamaged) VALUES
('0123704901', 1, 1, 0, 0),
('0123944244', 1, 1, 0, 0),
('0124077269', 1, 1, 0, 0),
('0205973361', 1, 1, 0, 0),
('0321696867', 4, 0, 0, 0),
('0321740904', 1, 0, 0, 1),
('0321884078', 1, 1, 0, 0),
('0470879521', 7, 0, 0, 0),
('0596802358', 2, 0, 0, 0),
('099040207X', 3, 0, 0, 1),
('1285057090', 1, 0, 0, 0),
('1429237198', 3, 0, 0, 0),
('1429261781', 1, 1, 0, 0),
('1449600069', 3, 0, 0, 1),
('1590597699', 1, 1, 0, 0);";

if ($conn->multi_query($sql)===TRUE)
		{
			$last_id = $conn->insert_id;
			//echo "New record inserted successfully. <br>";
		}
		else
		{
			echo "Error creating record :" . $conn->error;
		}


		
//

	$sql = "Use C0705705_Library";
	if ($conn->query($sql)=== TRUE)
	{

	$sql = "CREATE TABLE if not exists floor("
."floorID int(11) NOT NULL AUTO_INCREMENT primary kEY,"
."NumAssistant int(11) NOT NULL,"
."NumCopier int(11) NOT NULL)";


  if ($conn->query($sql)===TRUE)
		{
			//echo "Table created successfully. <br>";
		}
		else
		{
			echo "Error creating Table :" . $conn->error;
		}

}
	else
	{
		echo "Error connecting database:" . $conn->error. "<br>";
	}




"INSERT INTO floor (FloorID, NumAssistant, NumCopier) VALUES
(1, 2, 2),
(2, 3, 3),
(3, 2, 3);";

if ($conn->multi_query($sql)===TRUE)
		{
			$last_id = $conn->insert_id;
			//echo "New record inserted successfully. <br>";
		}
		else
		{
			echo "Error creating record :" . $conn->error;
		}

//


	$sql = "Use C0705705_Library";
	if ($conn->query($sql)=== TRUE)
	{

	$sql = "CREATE TABLE if not exists issue("
."userID int(11) NOT NULL AUTO_INCREMENT primary kEY,"
."Username varchar(15) NOT NULL,"
."ISBN char(14) NOT NULL,"
."CopyID int(11) NOT NULL,"
."IssueID int(4) NOT NULL,"
."ExtenDate date DEFAULT NULL,"
."IssueDate date NOT NULL,"
."ReturnDate date NOT NULL,"
."NumExten int(11) NOT NULL)";



if ($conn->query($sql)===TRUE)
		{
			//echo "Table created successfully. <br>";
		}
		else
		{
			echo "Error creating Table :" . $conn->error;
		}

}
	else
	{
		echo "Error connecting database:" . $conn->error. "<br>";
	}


"INSERT INTO issue (Username,ISBN, CopyID, IssueID, ExtenDate, IssueDate,ReturnDate, NumExten) VALUES
('aclark', '0124077269', 1, 115, '2015-04-13', '2015-03-31', '2015-04-27', 1),
('ahart', '0123704901', 3, 150, NULL, '2015-04-19', '2015-05-03', 0),
('apiper', '0321696867', 1, 64, '2015-01-12', '2015-01-12', '2015-01-26', 0),
('bturner', '0321884078', 1, 119, '2015-04-07', '2015-04-07', '2015-04-21', 0),
('cbenson', '1452257876', 1, 116, '2015-04-15', '2015-04-11', '2015-04-29', 1),
('ediao', '0124077269', 1, 74, '2015-02-10', '2015-02-10', '2015-02-24', 0),
('ediao', '0321696867', 1, 89, '2015-02-10', '2015-02-10', '2015-02-24', 0),
('ediao', '099040207X', 2, 148, NULL, '2015-04-16', '2015-04-30', 0),
('gkimberly', '0596802358', 1, 177, NULL, '2015-04-20', '2015-05-04', 0),
('gstarr', '0124077269', 2, 73, '2015-01-05', '2015-01-05', '2015-01-19', 0),
('hclifton', '0205973361', 2, 166, NULL, '2015-04-21', '2015-05-05', 0),
('hclifton', '0470879521', 2, 120, NULL, '2015-04-17', '2015-05-01', 0),
('hsun', '0123704901', 3, 47, '2015-01-05', '2015-01-05', '2015-01-19', 0),
('hsun', '1590597699', 1, 72, '2015-02-03', '2015-02-03', '2015-02-17', 0),
('kburns', '0123944244', 1, 61, '2015-01-25', '2015-01-25', '2015-02-09', 0),
('kburns', '0321696867', 2, 54, '2015-01-19', '2015-01-16', '2015-02-03', 1),
('kburns', '099040207X', 1, 117, '2015-04-15', '2015-04-15', '2015-04-29', 0),
('kburns', '1429261781', 1, 111, '2015-04-19', '2015-04-14', '2015-05-03', 1),
('lnarang', '0123944244', 1, 79, '2015-02-11', '2015-02-04', '2015-02-25', 1),
('lnarang', '1429261781', 1, 75, '2015-03-05', '2015-02-05', '2015-02-26', 2),
('lnoel', '0123704901', 2, 44, '2015-01-01', '2015-01-01', '2015-01-05', 0),
('ssong', '0123944244', 2, 184, NULL, '2015-04-21', '2015-05-05', 0),
('thwang', '0470879521', 4, 78, '2015-02-03', '2015-02-03', '2015-02-17', 0);";

if ($conn->multi_query($sql)===TRUE)
		{
			$last_id = $conn->insert_id;
			//echo "New record inserted successfully. <br>";
		}
		else
		{
			echo "Error creating record :" . $conn->error;
		}




	$sql = "Use C0705705_Library";
	if ($conn->query($sql)=== TRUE)
	{

// 	$sql = "CREATE TABLE if not exists issue("
// ."userID int(11) NOT NULL AUTO_INCREMENT primary kEY,"
// ."Username varchar(15) NOT NULL,"
// ."ISBN char(14) NOT NULL,"
// ."CopyID int(11) NOT NULL,"
// ."IssueID int(4) NOT NULL,"
// ."ExtenDate date DEFAULT NULL,"
// ."IssueDate date NOT NULL,"
// ."ReturnDate date NOT NULL,"
// ."NumExten int(11) NOT NULL)";



if ($conn->query($sql)===TRUE)
		{
			//echo "Table created successfully. <br>";
		}
		else
		{
			echo "Error creating Table :" . $conn->error;
		}

}
	else
	{
		echo "Error connecting database:" . $conn->error. "<br>";
	}



	






?>